from django.shortcuts import render

# Create your views here.

def index(req):
    return render(req,'index.html')

def Registration(req):
    return render(req,'Registration.html')

def Register1(req):
    print("Hello...............")
    print(req.POST)
    print(req.FILES)
    print(req.META)
    # print(req.Settings)
    n=req.POST.get('name')
    e=req.POST.get('email')
    c=req.POST.get('contact')
    p=req.POST.get('password')
    ph=req.FILES.get('photo')
    v=req.FILES.get('video')
    a=req.FILES.get('audio')
    d=req.FILES.get('resume')
    print(n,e,c,p,ph,v,a,d,sep=',')

def Login(req):
    return render(req,'Login.html')

